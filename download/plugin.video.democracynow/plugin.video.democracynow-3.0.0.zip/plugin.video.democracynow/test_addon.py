import unittest

if __name__ == '__main__':
    from addon import get_json, current_show, string_correction, thumb_replacement
else:
    from .addon import get_json, current_show, string_correction, thumb_replacement


class WebSiteTestCase(unittest.TestCase):
    """Test WebSite class"""

    def test_response_is_dict(self):
        # self.assertEqual(type(get_json(current_show)), type(dict()))
        # Use isinstance() rather then type()
        self.assertIsInstance(get_json(current_show), dict, "\nThis is not a json object or dict.")

    def test_response_have_items(self):
        self.assertTrue(get_json(current_show).get('items'))

    def test_items_is_correct_type(self):
        for video in get_json(current_show)['items']:
            if video['itemType'] == 'story' or video['itemType'] == 'headline_section':
                if video['itemType'] == 'headline_section':
                    title = u'Headlines'
                else:
                    title = string_correction(video['title'])

                url = ''
                for _video in video['media']:
                    if 'High' in _video['title']:
                        url = _video['src']
                    else:
                        pass

                try:
                    thumb = video['images'][0]['url']
                except KeyError:
                    thumb = thumb_replacement

                try:
                    duration = int(video['duration'])
                except KeyError:
                    duration = int

                try:
                    summary = string_correction(video['summary'])
                except KeyError:
                    summary = u''
                # self.assertEqual(type(title), type(str()))
                # self.assertEqual(type(duration), type(int()))
                # self.assertEqual(type(summary), type(str()))
                # Use isinstance() rather then type()
                self.assertIsInstance(title, str, "\nTitle is not a string!")
                self.assertIsInstance(duration, int, "\nDuration is not a integer!")
                self.assertIsInstance(summary, str, "\nSummary is not a string!")
                self.assertTrue(url.startswith('https'), "\nURL is not starting with https!")
                self.assertTrue(thumb.startswith('https'), "\nURL of thumbnails is not starting with https!")


if __name__ == '__main__':
    unittest.main()
