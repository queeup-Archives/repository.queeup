__version__ = '0.5.2'

from .region import CacheRegion, register_backend, make_region
