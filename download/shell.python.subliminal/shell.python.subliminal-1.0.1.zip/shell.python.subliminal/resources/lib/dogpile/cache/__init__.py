__version__ = '0.5.6'

from .region import CacheRegion, register_backend, make_region  # noqa
