# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_version = addon.getAddonInfo('version')
language_string = addon.getLocalizedString

dialog = xbmcgui.Dialog()
ok = dialog.ok(addon_name, language_string(30001), language_string(30002))
