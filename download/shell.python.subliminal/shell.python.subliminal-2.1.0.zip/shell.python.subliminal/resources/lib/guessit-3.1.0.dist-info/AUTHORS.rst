Copyright (c) 2011 - 2018, The GuessIt contributors.

GuessIt is an opensource project written and maintained by passionate people.

If you feel your name should belong to this list, please `open an issue <https://github.com/guessit/guessit/issues>`_

Author and contributors of current guessit version (``2.x``/``3.x``):

- Rémi Alvergnat <toilal.dev@gmail.com>
- Rato <rato.aq2@gmail.com>

Author and contributors of initial guessit version (``0.x``/``1.x``):

- Nicolas Wack <wackou@gmail.com>
- Ricard Marxer <ricardmp@gmail.com>