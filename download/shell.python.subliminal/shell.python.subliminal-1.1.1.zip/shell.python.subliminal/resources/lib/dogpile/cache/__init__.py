__version__ = '0.5.7'

from .region import CacheRegion, register_backend, make_region  # noqa
