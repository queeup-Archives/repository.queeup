from oslotest import base as test_base


class TestCase(test_base.BaseTestCase):
    pass
