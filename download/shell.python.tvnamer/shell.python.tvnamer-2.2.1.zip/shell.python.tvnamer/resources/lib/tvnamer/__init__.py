#!/usr/bin/env python

"""tvnamer - Automagical TV episode renamer

Uses data from www.thetvdb.com (via tvdb_api) to rename TV episode files from
"some.show.name.s01e01.blah.avi" to "Some Show Name - [01x01] - The First.avi"
"""

__version__ = (2, 2, 1)
__author__ = "dbr/Ben"
