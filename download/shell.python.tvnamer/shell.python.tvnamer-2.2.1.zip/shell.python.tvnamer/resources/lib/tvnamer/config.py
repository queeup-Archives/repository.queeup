#!/usr/bin/env python

"""Holds Config singleton
"""

from config_defaults import defaults

Config = dict(defaults)
