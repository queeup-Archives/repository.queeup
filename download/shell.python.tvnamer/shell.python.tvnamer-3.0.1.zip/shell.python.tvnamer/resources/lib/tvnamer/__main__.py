"""Allows executing tvnamer like so:

    python -m tvnamer show.s01e01.avi etc
"""

from .main import main

if __name__ == "__main__":
    main()
