#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmcgui
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__plugin__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')
__language__ = __addon__.getLocalizedString

dialog = xbmcgui.Dialog()
ok = dialog.ok(__plugin__, __language__(30001), __language__(30002))
